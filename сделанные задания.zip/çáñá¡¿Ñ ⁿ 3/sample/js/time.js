let time = Date(); 
// выводим текущее время 
alert(time);

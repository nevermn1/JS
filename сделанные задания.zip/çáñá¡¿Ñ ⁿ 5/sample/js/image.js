let img1 = "<img src='images/img1.jpg'>"; 
let img2 = "<img src='images/img2.jpg'>"; 
let img3 = "<img src='images/img3.jpg'>"; 